package com.example.pm;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.TextView;


public class InActivity extends AppCompatActivity {
    private static final String TAG = "InActivity";

    private TextView tv_count;
    private Button btn_add, btn_minus;
    private EditText textView15,textView;
    private ImageButton ibtn_no, ibtn_yes;
    private int count =0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_in);

        tv_count=findViewById(R.id.tv_count);
        tv_count.setText(count+"");

        textView15 = (EditText) findViewById(R.id.textView15);
        textView = (EditText)findViewById(R.id.textView);
        tv_count = (TextView)findViewById(R.id.tv_count);

        btn_add = findViewById(R.id.btn_add);
        btn_minus = findViewById(R.id.btn_minus);

        ibtn_yes = (ImageButton)findViewById(R.id.ibtn_yes);
        ibtn_no = (ImageButton)findViewById(R.id.ibtn_no);

        ibtn_no.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Intent intent = new Intent(InActivity.this, ReceiveActivity.class);
            }
        });

        ibtn_yes.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Intent i = new Intent(InActivity.this, ReceiveActivity.class);

                String name = textView15.getText().toString();
                String count = tv_count.getText().toString();
                String people = textView.getText().toString();


                i.putExtra("name",name);
                i.putExtra("count",count);
                i.putExtra("people",people);

                startActivity(i);

            }
        });

        btn_add.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                count++;
                tv_count.setText(count+"");
            }
        });

        btn_minus.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                count--;
                tv_count.setText(count+"");
            }
        });



            }

    }