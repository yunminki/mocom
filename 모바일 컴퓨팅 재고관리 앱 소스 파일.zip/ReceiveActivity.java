package com.example.pm;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageButton;
import android.widget.TextView;

public class ReceiveActivity extends AppCompatActivity {

    private ImageButton plus;
    private TextView textView4, textView5, textView6;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_receive);

        textView4 = (TextView)findViewById(R.id.textView4);
        textView5 = (TextView)findViewById(R.id.textView5);
        textView6 = (TextView)findViewById(R.id.textView6);

        Intent intent = getIntent();

        String name = intent.getStringExtra("name");
        String count = intent.getStringExtra("count");
        String people = intent.getStringExtra("people");

        textView4.setText(name);
        textView5.setText(count);
        textView6.setText(people);



        plus = findViewById(R.id.plus);



        plus.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Intent intent = new Intent(ReceiveActivity.this, InActivity.class);
                startActivity(intent);
            }
        });



    }
}